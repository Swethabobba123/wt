require 'test_helper'

class PersonControllerTest < ActionDispatch::IntegrationTest
  test "should get list" do
    get person_list_url
    assert_response :success
  end

end
