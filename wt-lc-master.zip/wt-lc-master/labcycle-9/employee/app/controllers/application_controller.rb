class ApplicationController < ActionController::Base
	def index
		puts "Hello"
	end
end
