class PersonController < ApplicationController
  def list
	@employees = Person.all
  end
end
