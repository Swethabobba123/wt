class CreatePeople < ActiveRecord::Migration[6.0]
	def self.up
		create_table :people do |t|
			t.column :ename, :string
			t.column :eno, :string
			t.column :sal, :integer
		end

		Person.create :ename=>"phani", :eno=>"E001", :sal=>10000
		Person.create :ename=>"salman", :eno=>"E002", :sal=>20000
		Person.create :ename=>"raja", :eno=>"E003", :sal=>30000
	end

	def self.down
		drop_table :people
	end
end
