import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class HintServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException {
		String names[] = {"phani", "srikar", "pavan", "raja", "salman"};
		String q = req.getParameter("q");
		String hint = "";
		if(!q.isEmpty()) {
			for(int i = 0; i < names.length; i++) {
				if(names[i].regionMatches(true, 0, q, 0, q.length())) {
					hint += hint.isEmpty() ? names[i] : ", " + names[i];
				}
			}
		}
		PrintWriter out = res.getWriter();
		if(hint.isEmpty())
			out.print("No Suggestions");
		else
			out.print(hint);
		out.close();
	}
}
