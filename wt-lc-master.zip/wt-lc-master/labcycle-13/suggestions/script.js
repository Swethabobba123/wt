var xhr;

function showHint(str) {
	if(str.length == 0) {
		document.getElementById("texthint").innerHTML = ""
		return;
	}
	xhr = (XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP")
	xhr.responseType = "text"
	url = "/suggestions/hint?q=" + str
	try {
		xhr.onreadystatechange = stateChanged
		xhr.open('GET', url, true)
		xhr.send(null)
	}
	catch(e) {
		alert('Unable to connect to server')
	}
}

function stateChanged() {
	if(xhr.readyState == 4 && xhr.status == 200) {
		document.getElementById("texthint").innerHTML = xhr.responseText
	}
}